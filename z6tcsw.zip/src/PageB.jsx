import React from "react";
function PageB(props) {
  const { fut } = props;

  return <p>fut</p>;
}
export default PageB;
