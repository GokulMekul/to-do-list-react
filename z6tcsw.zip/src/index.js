import React from "react";
import ReactDOM from "react-dom";
import APP from "./App";
const root = document.getElementById("root");
ReactDOM.render(
  <div>
    <APP />
  </div>,

  root
);
